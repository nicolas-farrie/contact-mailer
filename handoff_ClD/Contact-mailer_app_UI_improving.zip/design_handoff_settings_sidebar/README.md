# Handoff : Page Paramètres à sidebar (Paramètres / Seafile / BookStack)

## Vue d'ensemble
Regrouper la configuration de l'application sous **une seule page Paramètres à deux volets** :
une **sidebar de navigation** à gauche (items *Paramètres*, *Seafile*, *BookStack*) et, à droite,
le contenu de la section sélectionnée. Aujourd'hui Seafile et BookStack sont des entrées
indépendantes de la barre de navigation principale ; l'objectif est de les consolider sous
Paramètres pour clarifier la navigation (ce sont des écrans de configuration, pas des écrans
de travail quotidien).

## À propos des fichiers de design
Les fichiers de `reference_prototype/` sont une **référence de design réalisée en HTML** — un
prototype interactif qui montre l'apparence et le comportement voulus, **pas du code à copier tel
quel**. La tâche est de **recréer ce design dans le codebase Flask/Jinja existant** (`nicolas-farrie/contact-mailer`,
branche `design/claude-design-v1`) en réutilisant ses patterns et ses classes CSS établies.

Le prototype simule la persistance via `localStorage` ; dans l'app réelle, la plomberie passe par
les routes Flask et les formulaires POST déjà en place (voir « Câblage backend »).

Le dossier `proposed/` contient une **implémentation Jinja/CSS de référence** alignée sur les
templates et les classes réels de la branche. C'est un point de départ à adapter, pas un drop-in
aveugle.

## Fidélité
**Haute fidélité (hifi)** pour la mise en page, les couleurs, l'espacement et les états. Les
valeurs exactes sont dans « Design Tokens » ci-dessous. Le contenu fonctionnel de Seafile/BookStack
existe déjà dans le codebase — il ne s'agit pas de le réinventer mais de le **réorganiser** dans
le nouveau layout.

---

## Écran : Paramètres (3 volets)

### Layout général
- Conteneur : `display:flex; gap:1.5rem; align-items:flex-start` (passe en pleine largeur — `container-wide`).
- **Sidebar (gauche)** : largeur fixe **220px**, `flex-shrink:0`.
  - Carte blanche : `background:#fff; border-radius:6px; box-shadow:0 1px 3px rgba(0,0,0,0.1); padding:0.5rem`.
  - **Sticky** : `position:sticky; top:1.5rem`.
  - **Pleine hauteur** : `min-height:calc(100vh - 104px)` (104px = navbar 56px + paddings verticaux du main 2×24px). C'est la modif esthétique demandée par le client : la sidebar descend jusqu'en bas de l'écran.
- **Contenu (droite)** : `flex:1; min-width:0; max-width:820px`.

### Sidebar — détail
- Libellé de section « Configuration » en tête : `padding:0.5rem 0.85rem 0.6rem; font-size:0.7rem; font-weight:600; letter-spacing:0.05em; text-transform:uppercase; color:#9ca3af`.
- Liste de liens : `display:flex; flex-direction:column; gap:0.125rem`.
- Chaque lien : `display:flex; align-items:center; justify-content:space-between; gap:0.5rem; padding:0.55rem 0.85rem; border-radius:6px; font-size:0.9rem; text-decoration:none`.
  - **Inactif** : `color:#374151; font-weight:500; background:transparent`.
  - **Hover** : `background:#f3f4f6`.
  - **Actif** : `color:#2563eb; font-weight:600; background:#eff6ff`.
- **Pastille « non configuré »** : petit point `7×7px; border-radius:99px; background:#f59e0b`, affiché à droite du libellé Seafile/BookStack quand l'intégration n'a pas d'URL configurée (`config.SEAFILE_URL` / `config.BOOKSTACK_URL` absent). Décision produit : on **affiche toujours** l'item (avec pastille) plutôt que de le masquer, pour la découvrabilité. *(Comportement actuel de la branche : l'item est carrément masqué via `{% if config.SEAFILE_URL %}`. À trancher avec le client.)*

### Volet 1 — « Paramètres » (général)
Identique au `settings.html` déjà finalisé dans la branche. Deux cartes empilées :
1. **Général** — champ *Nom de l'application* (`app_name`, maxlength 60, max-width 360px) + bouton Enregistrer. POST vers `settings` avec `section=general`.
2. **Apparence de la page de connexion** — grille 2 colonnes : aperçu (image + voile) à gauche, contrôles à droite (upload image `login_bg`, slider d'assombrissement `login_overlay` 0–70, bouton Supprimer). POST `multipart/form-data` vers `settings` avec `section=login_appearance` ; suppression via `settings_clear_login_bg`.

→ **Aucun changement de contenu ici**, on le place juste dans le volet droit du nouveau layout.

### Volet 2 — « Seafile »
Reprend **tel quel** le contenu de `templates/seafile.html` (page-header + `form-card` empilées) :
en-tête « Seafile : {url} », info-box *Fonctionnement*, bloc mots de passe temporaires (conditionnel),
invitations en attente (conditionnel), Régénérer les mots de passe, Groupes Seafile (+ table des groupes
existants), Pousser une liste vers Seafile. Routes inchangées (`seafile`, `seafile_reset_passwords`,
`seafile_sync_groups`, `seafile_push`, `seafile_send_invitations`, endpoint AJAX `/seafile/contacts/<id>`).

### Volet 3 — « BookStack »
Reprend **tel quel** le contenu de `templates/bookstack.html` : en-tête, info-box, section Rôles
(+ bouton Synchroniser + table), section Pousser une liste (liste + rôle + case invitation). Routes
inchangées (`bookstack`, `bookstack_sync_roles`, `bookstack_push`).

---

## Approche d'implémentation recommandée (Jinja, faible risque)

Plutôt que d'inliner Seafile/BookStack dans un seul gros template ou de gérer du JS de
toggle, **réutiliser le système de templates Flask** : un layout partagé + 3 routes qui le remplissent.

1. **Créer `templates/settings_layout.html`** (fourni dans `proposed/`) : il `extends "base.html"`,
   force `container-wide`, et rend la sidebar + un `{% block settings_content %}`. La surbrillance de
   l'item actif se base sur une variable `active_tab`.

2. **Faire pointer les 3 templates sur ce layout** :
   - `settings.html` : `{% extends "settings_layout.html" %}` + `{% block settings_content %}…{% endblock %}` (contenu général actuel).
   - `seafile.html` : remplacer `{% extends "base.html" %}` → `{% extends "settings_layout.html" %}` et `{% block content %}` → `{% block settings_content %}`. Aucune autre modif du contenu.
   - `bookstack.html` : idem.

3. **Passer `active_tab` depuis les routes** Flask (`render_template(..., active_tab='general'|'seafile'|'bookstack')`). C'est plus sûr que `{% set %}` côté template (problème de portée avec l'héritage Jinja).

4. **Sidebar « non configuré »** : utiliser directement `config.SEAFILE_URL` / `config.BOOKSTACK_URL` (déjà accessibles dans tous les templates) pour la pastille — pas besoin de passer de variable supplémentaire.

5. **Nettoyer la navbar** (`base.html`) : retirer les deux liens conditionnels Seafile et BookStack (bloc `{% if config.BOOKSTACK_URL %}` / `{% if config.SEAFILE_URL %}`), garder l'item **Paramètres**. Mettre à jour la règle `active` de Paramètres pour englober les endpoints seafile/bookstack :
   `{% if request.endpoint in ['settings','settings_clear_login_bg','seafile','seafile_sync_groups','seafile_push','seafile_reset_passwords','seafile_send_invitations','bookstack','bookstack_sync_roles','bookstack_push'] %}class="active"{% endif %}`.

6. **CSS** : ajouter le bloc de `proposed/style_additions.css` à `static/style.css`. Tout le reste réutilise les classes existantes (`.card`, `.form-card`, `.data-table`, `.info-box`, `.btn`, `.btn-primary`, `.btn-action`, `.form-group`, `.page-header`).

> ⚠️ La branche est **en avance** sur la copie locale de ce projet pour `base.html` (PWA `manifest`/`theme-color`, branding multi-instance `INSTANCE_NAME`/`DISPLAY_NAME`, icône PNG, `{{ app_name }}` dynamique). **Travailler à partir de `base.html` de la branche**, ne pas l'écraser avec une version antérieure.

---

## Comportement responsive (< 768px)
La sidebar 220px + contenu côte à côte ne tient pas sur mobile. Recommandation (incluse dans
`proposed/style_additions.css`) :
- `.settings-layout` passe en `flex-direction:column`.
- La sidebar devient une **barre d'onglets horizontale** scrollable en haut (`flex-direction:row; overflow-x:auto`), `position:static`, `min-height:0`, libellé « Configuration » masqué.
- `.settings-content` repasse en `max-width:none`.
- Les grilles 2 colonnes des formulaires (déjà gérées par `.form-row`/`@media` existant) repassent en 1 colonne.

---

## Design Tokens
Réutiliser les variables déjà définies dans `static/style.css` :
- Primaire : `--primary #2563eb`, `--primary-dark #1d4ed8`
- Action (vert) : `--action #166534`
- Danger : `--danger #dc2626`
- Warning : `--warning #f98a38` (la pastille sidebar utilise toutefois **#f59e0b**, l'ambre des badges « en attente »)
- Gris : `--gray-50 #f9fafb`, `--gray-100 #f3f4f6`, `--gray-200 #e5e7eb`, `--gray-300 #d1d5db`, `--gray-500 #6b7280`, `--gray-700 #374151`, `--gray-900 #111827`
- Rayon : `--radius 6px`
- Surbrillance item actif sidebar : fond `#eff6ff`, texte `#2563eb`
- Ombre carte : `0 1px 3px rgba(0,0,0,0.1)`
- Police : pile système (`-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif`)

## Interactions & états
- Clic sur un item de sidebar → navigation vers la route correspondante (pas de JS, navigation serveur classique).
- Sticky : la sidebar reste visible au défilement des volets longs (Seafile est long).
- Les formulaires conservent leur comportement actuel (POST, flash messages via `get_flashed_messages`, confirmations JS sur suppression, AJAX `/seafile/contacts/<id>` pour la liste de contacts à régénérer).
- États hover/active de la sidebar : voir « Sidebar — détail ».

## Fichiers concernés
Dans la branche `design/claude-design-v1` :
- `templates/base.html` — retirer liens Seafile/BookStack de la navbar, ajuster `active` de Paramètres.
- `templates/settings.html` — extends le nouveau layout.
- `templates/seafile.html` — extends le nouveau layout (contenu inchangé).
- `templates/bookstack.html` — extends le nouveau layout (contenu inchangé).
- `templates/settings_layout.html` — **nouveau** (voir `proposed/`).
- `static/style.css` — ajouter les règles `.settings-layout` & co (voir `proposed/`).
- `app.py` — routes `settings`, `seafile`, `bookstack` : passer `active_tab`.

Référence de design : `reference_prototype/Contact Mailer.dc.html` (ouvrir dans un navigateur ;
se connecter → menu Paramètres → basculer entre les onglets de la sidebar). Le volet Paramètres/
Seafile/BookStack y est entièrement maquetté.
