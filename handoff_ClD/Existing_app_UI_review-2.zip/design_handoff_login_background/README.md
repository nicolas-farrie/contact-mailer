# Handoff : Image de fond personnalisable (page de connexion) + page admin « Paramètres »

## Overview
Ajout de deux choses au projet **contact-mailer** :
1. Une **image de fond personnalisable** sur la page de connexion (`login.html`).
2. Une nouvelle **page d'administration « Paramètres »** (`/settings`) où un admin :
   - téléverse / supprime l'image de fond de connexion,
   - règle l'**assombrissement** (voile sombre) appliqué par-dessus l'image pour garder le formulaire lisible,
   - modifie le **nom de l'application** (affiché dans la navbar + sur la page de connexion).

La page Paramètres est conçue pour **accueillir d'autres réglages admin** par la suite (sections empilées).

## About the Design Files
Le fichier `Contact Mailer.dc.html` dans ce bundle est une **référence de design en HTML** — un prototype interactif qui montre l'apparence et le comportement voulus. **Ce n'est pas le code de production à copier tel quel.**

La tâche est de **recréer ce comportement dans l'environnement réel du dépôt** : backend **Flask + templates Jinja2**, CSS dans `static/style.css`. Le prototype utilise `localStorage` comme raccourci ; en production il faut un **vrai stockage serveur** (fichier + config persistée). Voir « Implémentation backend » plus bas.

## Fidelity
**Hi-fi.** Couleurs, espacements, typographie et interactions sont définitifs et alignés sur `DESIGN.md` / `static/style.css` existants. Réutiliser les classes et variables CSS du projet (`--primary`, `.btn`, `.form-group`, `.card`, etc.) plutôt que de réécrire des styles inline.

---

## Écran 1 — Page de connexion (modif de `login.html`)

### Comportement
- Si **aucune** image de fond n'est configurée : fond neutre `#f3f4f6` (inchangé visuellement par rapport à l'existant), titre en `#111827`, lien en `--primary`.
- Si une image **est** configurée :
  - L'image couvre tout l'écran (`object-fit: cover`, centrée).
  - Un **voile sombre** est superposé : `rgba(17, 24, 39, <opacité>)` où `<opacité>` est réglable (0 → 0.70, défaut **0.35**).
  - Le titre passe en **blanc** (`#fff`) avec `text-shadow: 0 1px 3px rgba(0,0,0,0.5)` ; le lien « Mot de passe oublié ? » passe en `#dbeafe`.
  - La carte blanche du formulaire reste inchangée (lisibilité garantie par le voile).

### Détail d'implémentation important (bug rencontré)
Ne **pas** injecter l'image via une propriété CSS `background: url(<data-uri>)` construite par interpolation : une data-URI contient `:` et `;` qui cassent le parsing de style. **Utiliser une vraie balise `<img>`** en couche de fond :
```html
<img src="<url-image>" style="position:absolute;inset:0;width:100%;height:100%;object-fit:cover">
<div style="position:absolute;inset:0;background:rgba(17,24,39,0.35)"></div>  <!-- voile -->
```
En production avec une URL serveur classique (`/static/uploads/login_bg.jpg`), un `background-image` CSS est tout à fait correct — le problème ne concernait que les data-URI du prototype.

---

## Écran 2 — Page admin « Paramètres » (`/settings`, nouveau)

Largeur de contenu max ~760px. Composée de **sections empilées** (cartes blanches, `border-radius:6px`, `box-shadow:0 1px 3px rgba(0,0,0,0.1)`, `padding:1.5rem`, espacées de `1.5rem`).

### Section « Général »
- Titre `h2` (1rem, 600) + sous-titre gris (`#6b7280`, 0.8rem).
- Champ texte **« Nom de l'application »** (max-width 360px). Modifié → mis à jour partout (navbar + login). Aide : « Affiché dans la barre de navigation et sur la page de connexion. »

### Section « Apparence de la page de connexion »
Grille 2 colonnes : `240px 1fr`, gap `1.5rem`.
- **Colonne gauche — Aperçu** : vignette `aspect-ratio:16/10`, bord `1px #e5e7eb`, montrant l'image (ou un placeholder monospace « Aucune image — fond neutre par défaut » si vide). Quand une image est présente, on superpose le voile + une petite carte blanche figurant le formulaire. Légende « Aperçu » dessous.
- **Colonne droite — Contrôles** :
  - `<input type="file" accept="image/*">` — « Image de fond ». Aide : « Formats : JPG, PNG, WebP. Recommandé : paysage, ≥ 1920×1080. »
  - Si image présente : bouton **« Supprimer l'image »** (rouge `--danger #dc2626`).
  - Si image présente : **slider** « Assombrissement (N%) » `min=0 max=70`, `accent-color:#2563eb`, défaut 35. Aide : « Voile sombre pour garder le formulaire lisible. »
- Bandeau info en bas : « Les modifications sont appliquées et enregistrées immédiatement. »

### Accès navbar
Un lien **« Paramètres »** est ajouté dans la navbar (après « Utilisateurs »). En production : **réserver aux admins** (`current_user.role == 'admin'`).

---

## State / Données à persister
Trois réglages globaux applicatifs :
| Clé | Type | Défaut | Usage |
|-----|------|--------|-------|
| `app_name` | string | `"Contact Mailer"` | Navbar + titre login |
| `login_bg` | image (fichier) ou null | null | Fond de la page login |
| `login_overlay` | float 0–0.70 | 0.35 | Opacité du voile sombre |

## Design Tokens (déjà dans `static/style.css`)
- Primary `#2563eb` / dark `#1d4ed8` — Danger `#dc2626`
- Texte `#111827`, gris `#374151` / `#6b7280` / `#9ca3af`
- Fond app `#f3f4f6`, bord `#e5e7eb` / `#d1d5db`
- Voile login `rgba(17,24,39, login_overlay)`
- Rayon `6px`, ombre carte `0 1px 3px rgba(0,0,0,0.1)`

## Implémentation backend (production — remplace le `localStorage` du proto)
1. **Modèle de config** : table `settings` (clé/valeur) ou un singleton `AppSettings` (`app_name`, `login_bg_path`, `login_overlay`).
2. **Route `GET/POST /settings`** (admin only) :
   - `POST` multipart : si fichier image fourni → valider type/MIME + taille, sauver dans `static/uploads/` (nom déterministe, ex. `login_bg.<ext>`), stocker le chemin ; gérer suppression ; mettre à jour `app_name` et `login_overlay`.
3. **`login.html`** : lire la config (via context processor pour `app_name` global) ; si `login_bg_path`, rendre la couche `<img>` + voile avec `login_overlay`.
4. **Context processor** exposant `app_name` à tous les templates (navbar).
5. **Sécurité upload** : whitelist d'extensions (jpg/jpeg/png/webp), limite de taille, `secure_filename`, éventuel re-encodage (Pillow) pour neutraliser les fichiers malveillants.

## Files
- **`code/`** — code prêt à intégrer (Flask/Jinja, à adapter aux noms réels du projet) :
  - `login.html` — page de connexion modifiée (couche `<img>` de fond + voile, titre/lien adaptés).
  - `settings.html` — nouvelle page admin « Paramètres » (sections Général + Apparence).
  - `style_additions.css` — styles à ajouter à `static/style.css`.
  - `settings_backend.py` — modèle clé/valeur, context processor (`app_name` / `login_bg_url` / `login_overlay`), routes `/settings` + `/settings/clear-login-bg`, upload sécurisé.
  - `base_navbar_snippet.md` — où ajouter le lien « Paramètres » (admin) dans `base.html`.
- `Contact Mailer.dc.html` — prototype interactif complet (référence visuelle/comportementale de toutes les pages).

### Mise en route (résumé)
1. Copier `settings_backend.py`, adapter `db` / `Setting` / `current_user.is_admin`.
2. `app.register_blueprint(settings_bp)` + `register_context_processor(app)` ; créer la table `settings`.
3. Remplacer `templates/login.html` par la version fournie ; ajouter `templates/settings.html`.
4. Coller `style_additions.css` dans `static/style.css`.
5. Ajouter le lien navbar (cf. `base_navbar_snippet.md`) ; créer `static/uploads/` (et l'ignorer dans git si besoin).
