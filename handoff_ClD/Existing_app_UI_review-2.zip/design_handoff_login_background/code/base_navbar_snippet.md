# Snippet — ajout du lien « Paramètres » dans la navbar

Dans `templates/base.html`, à l'intérieur du bloc admin
(`{% if current_user.is_admin %} … {% endif %}` des `.nav-links`),
ajouter le lien Paramètres — par exemple juste après « Utilisateurs » :

```jinja
<a href="{{ url_for('settings_bp.settings') }}"
   {% if request.endpoint == 'settings_bp.settings' %}class="active"{% endif %}>Paramètres</a>
```

Contexte (extrait existant de base.html pour situer où l'insérer) :

```jinja
{% if current_user.is_admin %}
<a href="{{ url_for('import_contacts') }}" {% if request.endpoint == 'import_contacts' %}class="active"{% endif %}>Import</a>
<a href="{{ url_for('users') }}" {% if request.endpoint in ['users', 'user_new', 'user_edit'] %}class="active"{% endif %}>Utilisateurs</a>

<!-- 👇 AJOUTER -->
<a href="{{ url_for('settings_bp.settings') }}" {% if request.endpoint == 'settings_bp.settings' %}class="active"{% endif %}>Paramètres</a>

{% if config.BOOKSTACK_URL %} … {% endif %}
{% endif %}
```

> Le titre de l'onglet et le `nav-brand` peuvent aussi utiliser `{{ app_name }}`
> (fourni par le context processor) au lieu de « Contact Mailer » en dur, si tu
> veux que le nom personnalisé apparaisse partout. Exemple dans `base.html` :
>
> ```jinja
> <div class="nav-brand">{{ app_name }} <span class="version-tag" …>v{{ config.APP_VERSION }}</span></div>
> ```
