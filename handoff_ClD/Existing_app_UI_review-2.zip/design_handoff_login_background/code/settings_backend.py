"""
settings_backend.py — Réglages applicatifs + page admin « Paramètres ».

Code de RÉFÉRENCE à adapter à la structure réelle du projet (noms de modules,
instance `db`, décorateurs d'auth, etc.). Couvre :
  - un stockage clé/valeur des réglages (table Setting)
  - un context processor exposant app_name / login_bg_url / login_overlay à TOUS les templates
  - les routes GET/POST /settings et POST /settings/clear-login-bg (admins only)
  - l'upload sécurisé de l'image de fond

Dépendances supposées déjà présentes : Flask, Flask-Login (current_user),
Flask-SQLAlchemy (db), Werkzeug. Pillow est recommandé pour re-encoder l'image.
"""

import os
import uuid
from functools import wraps

from flask import (
    Blueprint, render_template, request, redirect, url_for, flash,
    current_app, abort,
)
from flask_login import login_required, current_user
from werkzeug.utils import secure_filename

# from . import db                      # <-- adapter à ton projet
# from .models import Setting           # <-- ou définir le modèle ici (voir plus bas)


# ----------------------------------------------------------------------
# Modèle de réglage clé/valeur (si tu n'as pas déjà un endroit pour ça)
# ----------------------------------------------------------------------
# class Setting(db.Model):
#     __tablename__ = "settings"
#     key   = db.Column(db.String(64), primary_key=True)
#     value = db.Column(db.Text, nullable=True)


DEFAULTS = {
    "app_name": "Contact Mailer",
    "login_bg_filename": "",     # nom de fichier dans static/uploads/, '' si aucun
    "login_overlay": "0.35",     # stocké en texte, converti en float à la lecture
}

ALLOWED_EXT = {"png", "jpg", "jpeg", "webp"}
MAX_BYTES = 5 * 1024 * 1024      # 5 Mo
UPLOAD_SUBDIR = "uploads"        # -> static/uploads/


# ---- Helpers de lecture / écriture ----------------------------------
def get_setting(key, default=None):
    row = Setting.query.get(key)
    if row is not None and row.value is not None:
        return row.value
    return DEFAULTS.get(key, default)


def set_setting(key, value):
    row = Setting.query.get(key)
    if row is None:
        row = Setting(key=key, value=value)
        db.session.add(row)
    else:
        row.value = value
    db.session.commit()


def _upload_dir():
    path = os.path.join(current_app.static_folder, UPLOAD_SUBDIR)
    os.makedirs(path, exist_ok=True)
    return path


# ----------------------------------------------------------------------
# Context processor : disponible dans TOUS les templates (navbar + login)
# ----------------------------------------------------------------------
def register_context_processor(app):
    @app.context_processor
    def inject_settings():
        fname = get_setting("login_bg_filename", "")
        login_bg_url = (
            url_for("static", filename=f"{UPLOAD_SUBDIR}/{fname}") if fname else None
        )
        try:
            overlay = float(get_setting("login_overlay", "0.35"))
        except (TypeError, ValueError):
            overlay = 0.35
        return {
            "app_name": get_setting("app_name", "Contact Mailer"),
            "login_bg_url": login_bg_url,
            "login_overlay": overlay,
        }


# ----------------------------------------------------------------------
# Décorateur admin (adapter à ton modèle User : is_admin / role == 'admin')
# ----------------------------------------------------------------------
def admin_required(f):
    @wraps(f)
    @login_required
    def wrapper(*args, **kwargs):
        if not getattr(current_user, "is_admin", False):
            abort(403)
        return f(*args, **kwargs)
    return wrapper


# ----------------------------------------------------------------------
# Routes
# ----------------------------------------------------------------------
bp = Blueprint("settings_bp", __name__)


@bp.route("/settings", methods=["GET", "POST"], endpoint="settings")
@admin_required
def settings():
    if request.method == "POST":
        section = request.form.get("section")

        if section == "general":
            name = (request.form.get("app_name") or "").strip()
            if name:
                set_setting("app_name", name[:60])
                flash("Paramètres généraux enregistrés.", "success")
            else:
                flash("Le nom de l'application ne peut pas être vide.", "danger")

        elif section == "login_appearance":
            # 1) opacité du voile
            raw = request.form.get("login_overlay")
            if raw is not None and raw != "":
                try:
                    pct = max(0, min(70, int(float(raw))))
                    set_setting("login_overlay", str(pct / 100))
                except ValueError:
                    pass

            # 2) image (optionnelle)
            file = request.files.get("login_bg")
            if file and file.filename:
                ext = file.filename.rsplit(".", 1)[-1].lower() if "." in file.filename else ""
                if ext not in ALLOWED_EXT:
                    flash("Format d'image non supporté (JPG, PNG ou WebP).", "danger")
                    return redirect(url_for("settings_bp.settings"))

                # contrôle de taille
                file.seek(0, os.SEEK_END)
                size = file.tell()
                file.seek(0)
                if size > MAX_BYTES:
                    flash("Image trop volumineuse (5 Mo maximum).", "danger")
                    return redirect(url_for("settings_bp.settings"))

                # nom unique -> évite le cache navigateur et les collisions
                fname = f"login_bg_{uuid.uuid4().hex}.{ext}"
                dest = os.path.join(_upload_dir(), secure_filename(fname))

                # RECOMMANDÉ : re-encoder via Pillow pour neutraliser un fichier piégé
                try:
                    from PIL import Image
                    img = Image.open(file.stream)
                    img.verify()           # détecte les fichiers corrompus/malveillants
                    file.seek(0)
                    img = Image.open(file.stream)
                    img.save(dest)
                except Exception:
                    # fallback simple si Pillow indisponible (moins sûr)
                    file.seek(0)
                    file.save(dest)

                # supprime l'ancienne image puis enregistre la nouvelle
                _delete_current_login_bg()
                set_setting("login_bg_filename", os.path.basename(dest))

            flash("Apparence de la connexion enregistrée.", "success")

        return redirect(url_for("settings_bp.settings"))

    # GET — le context processor fournit déjà app_name / login_bg_url / login_overlay
    return render_template("settings.html")


@bp.route("/settings/clear-login-bg", methods=["POST"], endpoint="settings_clear_login_bg")
@admin_required
def settings_clear_login_bg():
    _delete_current_login_bg()
    set_setting("login_bg_filename", "")
    flash("Image de fond supprimée.", "success")
    return redirect(url_for("settings_bp.settings"))


def _delete_current_login_bg():
    fname = get_setting("login_bg_filename", "")
    if fname:
        path = os.path.join(_upload_dir(), secure_filename(fname))
        try:
            os.remove(path)
        except OSError:
            pass


# ----------------------------------------------------------------------
# Câblage dans l'app factory / app principale :
#
#   from .settings_backend import bp as settings_bp, register_context_processor
#   app.register_blueprint(settings_bp)
#   register_context_processor(app)
#
# Puis `flask db migrate` / `db.create_all()` pour créer la table `settings`.
# ----------------------------------------------------------------------
